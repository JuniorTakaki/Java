package Restaurante;

import Cozinha.Cozinha;
import Endereco.Endereco;
import Pagamento.Pagamento;
import Produto.Produto;
import Usuario.Usuario;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

    public class Restaurante {
        private String nome;
        private BigDecimal taxaFrete;
        private Boolean ativo;
        private Boolean aberto;
        private LocalDateTime dataCadastro;
        private LocalDateTime dataAtualizacao;
        private Cozinha cozinha;
        private List<Pagamento> formasPagamento;
        private List<Usuario> responsaveis;
        private Endereco endereco;
        private List<Produto> produtos;


        public String getNome() {
            return nome;
        }

        public void setNome(String nome) {
            this.nome = nome;
        }

        public BigDecimal getTaxaFrete() {
            return taxaFrete;
        }

        public void setTaxaFrete(BigDecimal taxaFrete) {
            this.taxaFrete = taxaFrete;
        }

        public Boolean getAtivo() {
            return ativo;
        }

        public void setAtivo(Boolean ativo) {
            this.ativo = ativo;
        }

        public Boolean getAberto() {
            return aberto;
        }

        public void setAberto(Boolean aberto) {
            this.aberto = aberto;
        }

        public LocalDateTime getDataCadastro() {
            return dataCadastro;
        }

        public void setDataCadastro(LocalDateTime dataCadastro) {
            this.dataCadastro = dataCadastro;
        }

        public LocalDateTime getDataAtualizacao() {
            return dataAtualizacao;
        }

        public void setDataAtualizacao(LocalDateTime dataAtualizacao) {
            this.dataAtualizacao = dataAtualizacao;
        }

        public Cozinha getCozinha() {
            return cozinha;
        }

        public void setCozinha(Cozinha cozinha) {
            this.cozinha = cozinha;
        }

        public List<Pagamento> getFormasPagamento() {
            return formasPagamento;
        }

        public void setFormasPagamento(List<Pagamento> formasPagamento) {
            this.formasPagamento = formasPagamento;
        }

        public List<Usuario> getResponsaveis() {
            return responsaveis;
        }

        public void setResponsaveis(List<Usuario> responsaveis) {
            this.responsaveis = responsaveis;
        }

        public Endereco getEndereco() {
            return endereco;
        }

        public void setEndereco(Endereco endereco) {
            this.endereco = endereco;
        }

        public List<Produto> getProdutos() {
            return produtos;
        }

        public void setProdutos(List<Produto> produtos) {
            this.produtos = produtos;
        }

        @Override
        public String toString() {
            return "Restaurante{" +
                    "nome='" + nome + '\'' +
                    ", taxaFrete=" + taxaFrete +
                    ", ativo=" + ativo +
                    ", aberto=" + aberto +
                    ", dataCadastro=" + dataCadastro +
                    ", dataAtualizacao=" + dataAtualizacao +
                    ", cozinha=" + cozinha +
                    ", formasPagamento=" + formasPagamento +
                    ", responsaveis=" + responsaveis +
                    ", endereco=" + endereco +
                    ", produtos=" + produtos +
                    '}';
        }

        public Restaurante(String nome, BigDecimal taxaFrete, Boolean ativo, Boolean aberto,
                           Cozinha cozinha, List<Pagamento> formasPagamento, List<Usuario> responsaveis,
                           Endereco endereco, List<Produto> produtos) {
            this.nome = nome;
            this.taxaFrete = taxaFrete;
            this.ativo = ativo;
            this.aberto = aberto;
            this.cozinha = cozinha;
            this.formasPagamento = formasPagamento;
            this.responsaveis = responsaveis;
            this.endereco = endereco;
            this.produtos = produtos;
            this.dataCadastro = LocalDateTime.now();
            this.dataAtualizacao = LocalDateTime.now();


        }
    }

