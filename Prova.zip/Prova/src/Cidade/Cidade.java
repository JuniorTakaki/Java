package Cidade;

import Estado.Estado;

public class Cidade {

    private String name;
    private Estado estado;

    public Cidade(String name, Estado estado) {
        this.name = name;
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "Cidade{" +
                "name='" + name + '\'' +
                ", estado=" + estado +
                '}';
    }
}
