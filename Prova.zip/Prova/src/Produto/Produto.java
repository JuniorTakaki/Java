package Produto;

import java.math.BigDecimal;

public class Produto {

    private String name;
    private String descricao;
    private BigDecimal preco;
    private boolean ativo;
    private Fotoproduto foto;

    // Construtor com todos os argumentos
    public Produto(String name, String descricao, BigDecimal preco, boolean ativo, Fotoproduto foto) {
        this.name = name;
        this.descricao = descricao;
        this.preco = preco;
        this.ativo = ativo;
        this.foto = foto;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public BigDecimal getPreco() {
        return preco;
    }

    public void setPreco(BigDecimal preco) {
        this.preco = preco;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }

    public Fotoproduto getFoto() {
        return foto;
    }

    public void setFoto(Fotoproduto foto) {
        this.foto = foto;
    }

    @Override
    public String toString() {
        return "Produto{" +
                "name='" + name + '\'' +
                ", descricao='" + descricao + '\'' +
                ", preco=" + preco +
                ", ativo=" + ativo +
                ", foto=" + foto +
                '}';
    }
}
