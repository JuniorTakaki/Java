package Produto;

public class Fotoproduto {

    private String nome;
    private String descricao;
    private String contentType;
    private Long tamanho;

    @Override
    public String toString() {
        return "Fotoproduto{" +
                "nome='" + nome + '\'' +
                ", descricao='" + descricao + '\'' +
                ", contentType='" + contentType + '\'' +
                ", tamanho=" + tamanho +
                '}';
    }

    public Fotoproduto(String nome, String descricao, String contentType){
        this.nome = nome;
        this.descricao = descricao;
        this.contentType = contentType;
        calculaTamanho();
    }

    private void calculaTamanho(){
        this.tamanho = 124L;
    }
}
