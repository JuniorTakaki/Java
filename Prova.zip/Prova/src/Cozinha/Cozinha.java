package Cozinha;

public class Cozinha {

    private String name;

    public Cozinha(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Cozinha{" +
                "name='" + name + '\'' +
                '}';
    }
}
