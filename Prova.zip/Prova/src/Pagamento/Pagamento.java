package Pagamento;

public class Pagamento {

    private String descricao;

    public Pagamento(String descricao) {
        this.descricao = descricao;
    }

    @Override
    public String toString() {
        return "Pagamento{" +
                "descricao='" + descricao + '\'' +
                '}';
    }
}
