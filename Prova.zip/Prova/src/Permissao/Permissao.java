package Permissao;

public class Permissao {
    private String name;
    private String descricao;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Permissao(String name, String descricao) {
        this.name = name;
        this.descricao = descricao;
    }

    @Override
    public String toString() {
        return "Permissao{" +
                "name='" + name + '\'' +
                ", descricao='" + descricao + '\'' +
                '}';
    }
}
