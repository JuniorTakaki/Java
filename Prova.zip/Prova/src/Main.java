import Cidade.Cidade;
import Cozinha.Cozinha;
import Endereco.Endereco;
import Estado.Estado;
import Grupo.Grupo;
import Pagamento.Pagamento;
import Pedido.Itempedido;
import Pedido.Pedido;
import Permissao.Permissao;
import Produto.Fotoproduto;
import Produto.Produto;
import Restaurante.Restaurante;
import Usuario.Usuario;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args){
        //cozinhas
        Cozinha japonesa = new Cozinha("japonesa");
        Cozinha churrasco = new Cozinha("Pizzaria");

        //formas pagamentos
        Pagamento debito = new Pagamento("débito");
        Pagamento credito = new Pagamento("credito");
        List<Pagamento> formaPagamentos = new ArrayList<Pagamento>();
        formaPagamentos.add(debito);
        formaPagamentos.add(credito);

        // cidades e enderecos
        Cidade jundiai = new Cidade("jundiai", Estado.SP);
        Cidade varzea = new Cidade("Várzea Paulista", Estado.SP);
        Endereco end_restaurante1 = new Endereco("11111-111", "logradouro1", "111", "Proximo a KSB", "centro", varzea);
        Endereco end_restaurante2 = new Endereco("22222-222", "logradouro2", "123", "ao lado do mercado BOA", "medeiros", varzea);
        Endereco end_cliente1 = new Endereco("33333-333", "logradouro3", "124", "proximo a estação de trem", "vila  bla", jundiai);
        Endereco end_cliente2 = new Endereco("44444-444", "logradouro4", "122", "portão azul", "vila tupi", varzea);

        // permissoes & grupos
        Permissao permissao_dono = new Permissao("dono", "poder total");
        List<Permissao> permissoesDono = new ArrayList<Permissao>();
        permissoesDono.add(permissao_dono);
        Grupo grupoDono = new Grupo("dono", permissoesDono);

        Permissao permissao_cliente = new Permissao("cliente médio", "cancelar e criar pedidos");
        List<Permissao> permissoesCliente = new ArrayList<Permissao>();
        permissoesCliente.add(permissao_cliente);
        Grupo grupoCliente = new Grupo("Cliente médio", permissoesCliente);

        // usuarios
        Usuario dono1 = new Usuario("Junior", "junior@gmail.com", "12321", grupoDono);
        Usuario dono2 = new Usuario("Takaki", "Takaki@gmail.com", "1234", grupoDono);
        List<Usuario> donos1 = new ArrayList<Usuario>();
        donos1.add(dono1);
        List<Usuario> donos2 = new ArrayList<Usuario>();
        donos2.add(dono1);
        donos2.add(dono2);

        Usuario cliente1 = new Usuario("Armando", "Armando1032@gmail.com", "2345236", grupoCliente);
        Usuario cliente2 = new Usuario("Joao", "joao10@gmail.com", "43534", grupoCliente);

        // BigDecimals
        BigDecimal precoPizza = new BigDecimal("40");
        BigDecimal precoSushi = new BigDecimal("30");
        BigDecimal precoFrete = new BigDecimal("10");
        BigDecimal frete = new BigDecimal("9.90");

        // Produto
        Fotoproduto foto1 = new Fotoproduto("sushi", "foto sushi", "linkImg");
        Produto sushi = new Produto("Sushi", "Delicioso sushi", precoSushi, true, foto1);
        Fotoproduto foto2 = new Fotoproduto("Pizzaria", "foto Pizza", "linkImg");
        Produto pizza = new Produto("Pizzaria", "Melhor pizza da regiao", precoPizza, true, foto2);
        List<Produto> produtosLoja1 = new ArrayList<Produto>();
        produtosLoja1.add(sushi);
        List<Produto> produtosLoja2 = new ArrayList<Produto>();
        produtosLoja2.add(pizza);

        // Restaurante
        Restaurante restaurante1 = new Restaurante("Hashi sushi", precoFrete, true, true, japonesa, formaPagamentos, donos1, end_restaurante1, produtosLoja1);
        Restaurante restaurante2 = new Restaurante("", precoFrete, true, true, churrasco, formaPagamentos, donos2, end_restaurante2, produtosLoja2);

        // ItemPedido
        Integer quantidade = 2;
        Itempedido itemPedido1 = new Itempedido(quantidade, precoSushi, "", sushi);
        List<Itempedido> itens1 = new ArrayList<Itempedido>();
        itens1.add(itemPedido1);

        Integer quantidade2 = 3;
        Itempedido itemPedido2 = new Itempedido(quantidade2, precoPizza, "ao ponto", pizza);
        List<Itempedido> itens2 = new ArrayList<Itempedido>();
        itens2.add(itemPedido2);

        // Pedido
        Pedido pedido1 = new Pedido(itemPedido1.getPrecoTotal(), frete, end_cliente1, cliente1, restaurante1, debito, itens1);
        Pedido pedido2 = new Pedido(itemPedido2.getPrecoTotal(), frete, end_cliente2, cliente2, restaurante2, credito, itens2);
        System.out.println("Pedidos: ");
        System.out.println("pedido 1: ");
        System.out.println(pedido1);
        System.out.println("");
        System.out.println("pedido 2:");
        System.out.println(pedido2);

        System.out.println("==========================================================");
        System.out.println("confirmando pedido");
        pedido1.confirmaPedido();
        System.out.println(pedido1);
        System.out.println("pedido 1: ");
        System.out.println("entrega confirmada");
        pedido1.confirmaEntrega();
        System.out.println("pedido 1: ");
        System.out.println(pedido1);

        System.out.println("================================================================");
        System.out.println("pedido 2 cancelado: ");
        pedido2.cancelarPedido();
        System.out.println("pedido 2: ");
        System.out.println(pedido2);

        System.out.println("Em resumo: ");
        System.out.println("pedido 1 => " + pedido1.getStatus());
        System.out.println("pedido 2 => " +pedido2.getStatus());



    }
}