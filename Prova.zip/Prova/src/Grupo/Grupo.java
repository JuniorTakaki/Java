package Grupo;

import Permissao.Permissao;

import java.util.ArrayList;
import java.util.List;

public class Grupo {

    private String nome;
    private List<Permissao> permissaos = new ArrayList<Permissao>();

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public List<Permissao> getPermissaos() {
        return permissaos;
    }

    public void setPermissaos(List<Permissao> permissaos) {
        this.permissaos = permissaos;
    }

    @Override
    public String toString() {
        return "Grupo{" +
                "nome='" + nome + '\'' +
                ", permissaos=" + permissaos +
                '}';
    }

    public Grupo(String nome, List<Permissao> permissaos){
        this.nome = nome;
        for (int i= 0; i < permissaos.size(); i++) {
            this.permissaos.add(permissaos.get(i));
        }


    }
}
