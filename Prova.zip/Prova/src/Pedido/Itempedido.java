package Pedido;

import Produto.Produto;

import java.math.BigDecimal;

public class Itempedido {
    private Integer quantidade;
    private BigDecimal precoUnitario;
    private BigDecimal precoTotal;
    private String observacao;
    private Produto produto;

    // Construtor sem argumentos (NoArgsConstructor)
    public Itempedido() {
    }




    // Construtor personalizado
    public Itempedido(Integer quantidade, BigDecimal precoUnitario, String observacao, Produto produto) {
        this.quantidade = quantidade;
        this.precoUnitario = precoUnitario;
        this.observacao = observacao;
        this.produto = produto;
        this.precoTotal = calculaPrecoTotal(quantidade, precoUnitario);
    }

    private BigDecimal calculaPrecoTotal(Integer quantidade, BigDecimal precoUnitario) {
        BigDecimal temp = BigDecimal.valueOf(quantidade);
        return precoUnitario.multiply(temp);
    }

    // Getters e Setters
    public Integer getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(Integer quantidade) {
        this.quantidade = quantidade;
        this.precoTotal = calculaPrecoTotal(quantidade, this.precoUnitario);
    }

    public BigDecimal getPrecoUnitario() {
        return precoUnitario;
    }

    public void setPrecoUnitario(BigDecimal precoUnitario) {
        this.precoUnitario = precoUnitario;
        this.precoTotal = calculaPrecoTotal(this.quantidade, precoUnitario);
    }

    public BigDecimal getPrecoTotal() {
        return precoTotal;
    }

    public void setPrecoTotal(BigDecimal precoTotal) {
        this.precoTotal = precoTotal;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }

    @Override
    public String toString() {
        return "ItemPedido{" +
                "quantidade=" + quantidade +
                ", precoUnitario=" + precoUnitario +
                ", precoTotal=" + precoTotal +
                ", observacao='" + observacao + '\'' +
                ", produto=" + produto +
                '}';
    }
}