package Pedido;


import Endereco.Endereco;
import Pagamento.Pagamento;
import Restaurante.Restaurante;
import Usuario.Usuario;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public class Pedido {

        private static Integer proxCodigo = 0;
        private String codigo;
        private BigDecimal subtotal;
        private BigDecimal taxaFrete;
        private BigDecimal valorTotal;
        private LocalDateTime dataCriacao;
        private LocalDateTime dataConfirmacao;
        private LocalDateTime dataEntregue;
        private LocalDateTime dataCancelamento;
        private StatusPedido status;
        private Endereco enderecoEntrega;
        private Usuario cliente;
        private Restaurante restaurante;
        private Pagamento formaPagamento;
        private List<Itempedido> itens;

        public Pedido(BigDecimal subtotal, BigDecimal taxaFrete, Endereco enderecoEntrega, Usuario cliente, Restaurante restaurante, Pagamento formaPagamento, List<Itempedido> itens) {
            this.subtotal = subtotal;
            this.taxaFrete = taxaFrete;
            this.enderecoEntrega = enderecoEntrega;
            this.cliente = cliente;
            this.restaurante = restaurante;
            this.formaPagamento = formaPagamento;
            this.itens = itens;

            this.codigo = novoCodigo();
            this.dataCriacao = LocalDateTime.now();
            this.status = StatusPedido.CRIADO;
            this.valorTotal = subtotal.add(taxaFrete);
        }

        public Pedido(){
            this.codigo = novoCodigo();
            this.status = StatusPedido.CRIADO;
        }

        private String novoCodigo(){
            Integer novoCodigo = Pedido.proxCodigo;
            Pedido.proxCodigo += 1;
            return "" + novoCodigo;
        }

        public void cancelarPedido(){
            this.status = StatusPedido.CANCELADO;
            this.dataCancelamento = LocalDateTime.now();
        }

        public void confirmaPedido(){
            this.status = StatusPedido.CONFIRMADO;
            this.dataConfirmacao = LocalDateTime.now();
        }

    public static Integer getProxCodigo() {
        return proxCodigo;
    }

    public static void setProxCodigo(Integer proxCodigo) {
        Pedido.proxCodigo = proxCodigo;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public BigDecimal getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(BigDecimal subtotal) {
        this.subtotal = subtotal;
    }

    public BigDecimal getTaxaFrete() {
        return taxaFrete;
    }

    public void setTaxaFrete(BigDecimal taxaFrete) {
        this.taxaFrete = taxaFrete;
    }

    public BigDecimal getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(BigDecimal valorTotal) {
        this.valorTotal = valorTotal;
    }

    public LocalDateTime getDataCriacao() {
        return dataCriacao;
    }

    public void setDataCriacao(LocalDateTime dataCriacao) {
        this.dataCriacao = dataCriacao;
    }

    public LocalDateTime getDataConfirmacao() {
        return dataConfirmacao;
    }

    public void setDataConfirmacao(LocalDateTime dataConfirmacao) {
        this.dataConfirmacao = dataConfirmacao;
    }

    public LocalDateTime getDataEntregue() {
        return dataEntregue;
    }

    public void setDataEntregue(LocalDateTime dataEntregue) {
        this.dataEntregue = dataEntregue;
    }

    public LocalDateTime getDataCancelamento() {
        return dataCancelamento;
    }

    public void setDataCancelamento(LocalDateTime dataCancelamento) {
        this.dataCancelamento = dataCancelamento;
    }

    public StatusPedido getStatus() {
        return status;
    }

    public void setStatus(StatusPedido status) {
        this.status = status;
    }

    public Endereco getEnderecoEntrega() {
        return enderecoEntrega;
    }

    public void setEnderecoEntrega(Endereco enderecoEntrega) {
        this.enderecoEntrega = enderecoEntrega;
    }

    public Usuario getCliente() {
        return cliente;
    }

    public void setCliente(Usuario cliente) {
        this.cliente = cliente;
    }

    public Restaurante getRestaurante() {
        return restaurante;
    }

    public void setRestaurante(Restaurante restaurante) {
        this.restaurante = restaurante;
    }

    public Pagamento getFormaPagamento() {
        return formaPagamento;
    }

    public void setFormaPagamento(Pagamento formaPagamento) {
        this.formaPagamento = formaPagamento;
    }

    public List<Itempedido> getItens() {
        return itens;
    }

    public void setItens(List<Itempedido> itens) {
        this.itens = itens;
    }

    @Override
    public String toString() {
        return "Pedido{" +
                "codigo='" + codigo + '\'' +
                ", subtotal=" + subtotal +
                ", taxaFrete=" + taxaFrete +
                ", valorTotal=" + valorTotal +
                ", dataCriacao=" + dataCriacao +
                ", dataConfirmacao=" + dataConfirmacao +
                ", dataEntregue=" + dataEntregue +
                ", dataCancelamento=" + dataCancelamento +
                ", status=" + status +
                ", enderecoEntrega=" + enderecoEntrega +
                ", cliente=" + cliente +
                ", restaurante=" + restaurante +
                ", formaPagamento=" + formaPagamento +
                ", itens=" + itens +
                '}';
    }

    public void confirmaEntrega(){
            this.status = StatusPedido.ENTREGUE;
            this.dataEntregue = LocalDateTime.now();



        }

    }
