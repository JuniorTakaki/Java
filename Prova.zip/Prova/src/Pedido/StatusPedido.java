package Pedido;

public enum StatusPedido {
    CRIADO,
    CONFIRMADO,
    ENTREGUE,
    CANCELADO
}